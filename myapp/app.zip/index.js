const express = require('express');

const app = express()
const port = 3000

app.get('/', (req, res) => {
    res.send('Día de la hamburguesa 2x1 en Carls Jr.')
})

app.get('/productos', (req, res) => {

    let productos = [
        {
            nombre: 'Hamburguesa',
            precio: 150
        },
        {
            nombre: 'Refresco',
            precio: 200
        },
        {
            nombre: 'Papas Fritas',
            precio: 50
        }
    ]

    let respuesta  = '<table border ="1">';
    productos.forEach(producto => {
        respuesta += `<tr><td>${producto.nombre}</td><td>${producto.precio}</td></tr>`;
    });
    respuesta += '</table>';
    
    res.send(respuesta)
})

app.listen(port, () => {
    console.log('Example app listening on port ' + port);
})